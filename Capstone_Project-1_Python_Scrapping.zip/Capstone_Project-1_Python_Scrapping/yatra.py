import requests
import json
import pandas as pd
from datetime import date
from pymongo import MongoClient

# Set up the date and MongoDB client
in_date = date.today().strftime('%d-%b-%y')
client = MongoClient('localhost', 27017)

# Define the database and collection names
db_name = f'yatra_bus_data_{in_date}'
db = client[db_name]
db_col = db[f"buses_data_{in_date}"]

# Set up headers for the HTTP request
headers = {
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-US,en;q=0.9',
    'Connection': 'keep-alive',
    'Referer': 'https://ebus.yatra.com/busview/busdesktop/search?src=Delhi&srcStnCode=YTDelhi&dest=Jaipur&destStnCode=YTJaipur&tt=O&ddate=2024-05-31&qty=1&source=fresco',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
    'corelationId': 'C943F2EC-AF81-4DE9-C44D-2169ED958E04',
    'sec-ch-ua': '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
}

# Define parameters for the HTTP request
params = {
    'src': 'Delhi',
    'dest': 'Jaipur',
    'ddate': '2024-05-31',
    'tt': 'O',
    'qty': '1',
    'srcStnCode': 'YTDelhi',
    'destStnCode': 'YTJaipur',
}

# Set the Excel file name
excel_filename = f'yatra_bus_data_{in_date}.xlsx'

# Send the HTTP request to get the bus data
response = requests.get('https://ebus.yatra.com/businfo/busdesktop/search', params=params, headers=headers)
print(response.status_code)

# Parse the JSON response
data_dict_list = []
if response.status_code == 200:
    page_response = response.text
    buses_data = json.loads(page_response)

    for bus in buses_data['result']['buses']:
        bus_data_dict = {
            'Bus Code': bus['opId'],
            'Bus Name': bus['opNm'],
            'Bus Time': bus['dt'],
            'Arrival Time': bus['at'],
            'Total Duration': bus['du'],
            'Price': bus['fare'],
            'Bus Type': bus['bType'],
            'Seat Type': bus['st'],
            'Amenities': bus['amenities']
        }
        data_dict_list.append(bus_data_dict)

    # Insert the data into MongoDB
    db_col.insert_many(data_dict_list)

    # Save the data to an Excel file
    df = pd.DataFrame(data_dict_list)
    df.to_excel(excel_filename, index=False)
    print("Successfully saved data to excel.")
else:
    print("Failed to fetch bus data.")
